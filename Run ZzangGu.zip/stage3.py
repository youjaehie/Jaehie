import random

from pico2d import *

import game_framework
import title_state

name = "Stage3"

zzanggu = None
third = None
back = None
enemy = None
leeseul = None

class BackGround:
    image = None ;
    def __init__(self):
        self.BackScroll = 0
        self.x = 0
        if self.image == None:
            self.image = load_image('background.png')
    def draw(self):
        self.image.draw(400 - self.BackScroll,300)
        self.image.draw(1200 - self.BackScroll,300)
        if self.BackScroll == 800 :
            self.BackScroll = 0
    def update(self):
        self.BackScroll+=10
        self.BackScroll%=800

class Third:
    image = None ;
    def __init__(self):
        if self.image == None:
            self.image = load_image('third_stage.jpg')
        self.TileScroll = 0
    def draw(self):
        self.image.draw(400-self.TileScroll,30)
        self.image.draw(1200-self.TileScroll,30)
        if self.TileScroll == 390 :
            self.TileScroll = 0
    def update(self):
        self.TileScroll += 15
        self.TileScroll%=1000

class Leeseul:
    image=None
    def __init__(self):
        if Leeseul.image == None:
            self.image=load_image('leeseul.png')
        self.x= 1050
        self.y= 190
        self.frame=0
    def draw(self):
        self.image.draw(self.x, self.y)
        #self.image.clip_draw_to_origin(55*self.frame,0,55,43,self.x,self.y,80,60)
    def update(self):
        self.frame=(self.frame+1)
        self.x-=1
        if self.x <820:
            self.x=820

class Enemy:
    Mommy_RIGHT_RUN = 4
    RIGHT_DIR ,LEFT_DIR = 1,-1

    Mommyimage = None

    MommyX = -50
    MommyY = 160
    Mommystate = Mommy_RIGHT_RUN
    Mommyframe = 0

    timer = 0
    def __init__(self):
        if Enemy.Mommyimage ==None:
            Enemy.Mommyimage = load_image('Mommy.png')
        self.dir = self.RIGHT_DIR

    def handle_right_run(self):
        self.MommyX += (self.dir*1)/1
        if (self.MommyX > 1200):
            self.MommyX = 0

    handle_state ={
        Mommy_RIGHT_RUN : handle_right_run,
    }
    def update(self):
        self.timer += 1
        if self.timer == 100:
            self.Mommyframe = (self.Mommyframe + 1) % 6
            self.timer = 0
        self.handle_state[self.Mommystate](self)

    def draw(self):
       self.Mommyimage.draw(self.MommyX, self.MommyY)

class Zzanggu:
    RUN, JUMP = 0, 1

    def handle_run(self):
        self.run_frame = (self.run_frame + 1)
        if self.keycheckright == True:
            self.x += 1

    def handle_jump(self):
        self.y -= (self.jump_frame - 3) * 20
        self.jump_frame += 1
        # delay(0.03)
        if self.jump_frame == 7:
            self.state = self.RUN
            self.run_frame = 0

    handle_state = {
        RUN: handle_run,
        JUMP: handle_jump
    }

    def update(self):
        self.handle_state[self.state](self)  # if가 없어짐 -> 처리속도,수정이 빠름

    def __init__(self):
        self.x, self.y = 70, 100
        self.run_frame, self.jump_frame = (0, 0)
        self.run = load_image('Zzanggu.png')
        self.jump = load_image('Zzanggu_jump.png')
        self.keycheckright, self.keycheckup = (False, False)
        self.state = self.RUN

    def draw(self):
        if self.state == 0:
            self.run.draw(self.x,self.y)
        elif self.state == 1:
            self.jump.draw(self.jump_frame * 100, 100, 100, 100)

def enter():
    global zzanggu, back, third, enemy, leeseul
    zzanggu = Zzanggu()
    back = BackGround()
    third = Third()
    enemy = Enemy()
    leeseul = Leeseul()
    pass

def exit():
    global zzanggu, back, third, enemy, leeseul
    del(zzanggu)
    del(back)
    del(third)
    del(enemy)
    del(leeseul)
    pass


def pause():
    pass

def resume():
    pass

def handle_events():
    global zzanggu
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and zzanggu.state == zzanggu.RUN:
            if event.key == SDLK_RIGHT:
                zzanggu.keycheckright = True
            elif event.key == SDLK_UP:
                zzanggu.state = 1
                zzanggu.jump_frame = 0
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT:
                zzanggu.keycheckright = False

def update():
    global zzanggu, back, third, enemy, leeseul
    back.update()
    zzanggu.update()
    third.update()
    enemy.update()
    leeseul.update()
    pass

def draw():
    global zzanggu, back, third, enemy, leeseul
    clear_canvas()
    back.draw()
    zzanggu.draw()
    third.draw()
    enemy.draw()
    leeseul.draw()
    delay(0.05)
    update_canvas()
    pass