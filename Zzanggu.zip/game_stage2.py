import random
import json
from pico2d import *
import game_framework
import game_title
import game_stage3
import stage3_class

from stage2_class import *

zzanggu = None
second_stage = None
background = None
enemy = None
house = None
stone = None
item = None
item2 = None

def enter():
    global zzanggu, background, second_stage, enemy, house, stone, item, item2
    zzanggu = Zzanggu()
    background = BackGround()
    second_stage= Second_stage()
    enemy = Enemy()
    house = House()
    stone = Stone()
    item = Item()
    item2 = Item2()
    pass

def exit():
    global zzanggu, back, second, enemy, house, stone, item, item2
    del(zzanggu)
    del(background)
    del(second_stage)
    del(enemy)
    del(house)
    del(stone)
    del(item)
    del(item2)
    pass


def pause():
    pass

def resume():
    pass

def handle_events():
    global zzanggu
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN and zzanggu.state == zzanggu.RUN:
            if event.key == SDLK_RIGHT:
                zzanggu.keycheckright = True
            elif event.key == SDLK_UP:
                zzanggu.state = 1
                zzanggu.jump_frame = 0
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT:
                zzanggu.keycheckright = False


def update():
    global zzanggu, back, second, enemy, house, stone, item, item2
    background.update()
    zzanggu.update()
    second_stage.update()
    enemy.update()
    house.update()
    stone.update()
    item.update()
    item2.update()
    pass

def draw():
    global zzanggu, background, second_stage, enemy, house, stone, item, item2
    clear_canvas()
    background.draw()
    zzanggu.draw()
    second_stage.draw()
    enemy.draw()
    house.draw()
    stone.draw()
    item.draw()
    item2.draw()
    delay(0.05)
    update_canvas()
    pass