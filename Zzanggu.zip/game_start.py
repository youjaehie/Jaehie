import game_framework

import game_framework
import game_logo

game_framework.run(game_logo)